#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_sonarr-sub-downloader-docker
----------------------------------
Tests for `sonarr-sub-downloader-docker` module.
"""

import pytest

from sonarr-sub-downloader-docker import sonarr-sub-downloader-docker


class TestSonarr-Sub-Downloader-Docker(object):

    @classmethod
    def setup_class(cls):
        pass

    @classmethod
    def teardown_class(cls):
        pass

    def test_something(self):
        pass

